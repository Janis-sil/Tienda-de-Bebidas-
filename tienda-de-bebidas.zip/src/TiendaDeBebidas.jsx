import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const products = [
  {
    name: "Fernet Branca",
    price: 500,
    image: "https://upload.wikimedia.org/wikipedia/commons/7/74/Fernet-branca.jpg",
  },
  {
    name: "Martini Bianco",
    price: 425,
    image: "https://upload.wikimedia.org/wikipedia/commons/f/f5/Martini_Bianco.jpg",
  },
];

export default function TiendaDeBebidas() {
  const [cart, setCart] = useState([]);
  const [form, setForm] = useState({ name: "", phone: "", payment: "Transferencia" });

  const addToCart = (product) => {
    setCart([...cart, product]);
  };

  const total = cart.reduce((sum, item) => sum + item.price, 0);

  const handleFormChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const generateWhatsAppLink = () => {
    const productList = cart.map((item) => `- ${item.name} $${item.price}`).join("\n");
    const message = `Hola, quiero hacer un pedido:\n\n${productList}\n\nTotal: $${total}\n\nNombre: ${form.name}\nTeléfono: ${form.phone}\nMétodo de pago: ${form.payment}`;
    return `https://wa.me/?text=${encodeURIComponent(message)}`;
  };

  return (
    <div className="min-h-screen bg-white p-4">
      <header className="flex items-center justify-between mb-6">
        <img src="/logo.png" alt="Tienda de Bebidas" className="h-16" />
        <Button>
          <a href="https://wa.me/" target="_blank" rel="noopener noreferrer">
            Contactar por WhatsApp
          </a>
        </Button>
      </header>

      <h1 className="text-2xl font-bold mb-4">Nuestros Productos</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {products.map((product, index) => (
          <Card key={index} className="rounded-2xl shadow-md">
            <CardContent className="p-4">
              <img src={product.image} alt={product.name} className="w-full h-48 object-cover rounded-xl mb-2" />
              <h2 className="text-xl font-semibold">{product.name}</h2>
              <p className="text-gray-600">${product.price}</p>
              <Button className="mt-2 w-full" onClick={() => addToCart(product)}>
                Agregar al carrito
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {cart.length > 0 && (
        <div className="mt-10 p-4 border rounded-xl shadow-md">
          <h2 className="text-xl font-bold mb-2">Carrito</h2>
          <ul className="mb-4">
            {cart.map((item, idx) => (
              <li key={idx} className="text-gray-700">{item.name} - ${item.price}</li>
            ))}
          </ul>
          <p className="font-semibold">Total: ${total}</p>

          <h3 className="text-lg font-bold mt-4">Tus datos</h3>
          <div className="grid gap-2 my-2">
            <Input placeholder="Nombre" name="name" value={form.name} onChange={handleFormChange} />
            <Input placeholder="Teléfono" name="phone" value={form.phone} onChange={handleFormChange} />
            <select
              name="payment"
              value={form.payment}
              onChange={handleFormChange}
              className="border p-2 rounded"
            >
              <option value="Transferencia">Transferencia</option>
              <option value="Débito">Débito</option>
            </select>
          </div>

          <Button className="mt-2 w-full">
            <a href={generateWhatsAppLink()} target="_blank" rel="noopener noreferrer">
              Finalizar pedido por WhatsApp
            </a>
          </Button>
        </div>
      )}

      <footer className="mt-12 text-center text-sm text-gray-500">
        Métodos de pago: Transferencia Bancaria, Tarjeta de Débito
      </footer>
    </div>
  );
}